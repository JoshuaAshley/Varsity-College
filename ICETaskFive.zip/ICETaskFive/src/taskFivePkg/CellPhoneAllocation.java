package taskFivePkg;

import javax.swing.JOptionPane;

public class CellPhoneAllocation
{

    public static void main(String[] args)
    {
        String employee1;
        String employee2;
        String employee3;

        employee1 = JOptionPane.showInputDialog(null, "Please enter the first employee name.").toUpperCase();
        employee2 = JOptionPane.showInputDialog(null, "Please enter the second employee name.").toUpperCase();
        employee3 = JOptionPane.showInputDialog(null, "Please enter the third employee name.").toUpperCase();

        String[] employees =
        {
            employee1, employee2, employee3
        };
        
        String[] cellNetProviders =
        {
            "VODACOM", "MTN", "CELL C"
        };
        
        String[] cellPhoneStart =
        {
            "072", "083", "084"
        };

        String output = "CELL PHONE NUMBER GENERATOR\n*******************************************\n";
        for (int i = 0; i < 3; i++)
        {
            int randomCellProvider = (int) Math.round(Math.random() * (2 - 0) + 0);
            
            int randomCellMiddle = (int) Math.round(Math.random() * (999 - 100) + 100);
            int randomCellPhoneEnd = (int) Math.round(Math.random() * (9999 - 1000) + 1000);
            String randomCellPhoneNumber = cellPhoneStart[randomCellProvider] + " " + randomCellMiddle + " - (" + randomCellPhoneEnd + ")";
            String cellProvider = cellNetProviders[randomCellProvider];
            
            output += employees[i] + " will be on the network " + cellProvider + " with the phone number " + randomCellPhoneNumber + "\n";
        }
        
        JOptionPane.showMessageDialog(null, output);

    }
}
